import streamlit as st
import google.generativeai as genai
import os

# Function to generate campaign idea (same as in idea_machine.py, but API key setup is slightly different for Streamlit)
def generate_campaign_idea_streamlit(campaign_parameters):
    """Generates a marketing campaign idea using Google Gemini Pro model for Streamlit app."""

    genai.configure(api_key=st.secrets["GOOGLE_API_KEY"]) # Access API key from Streamlit secrets

    prompt_message = f"""
    You're a key expert on our creative marketing team.

    Generate a creative marketing campaign idea for the following:

    Industry: {campaign_parameters['industry']}
    Target Audience: {campaign_parameters['target_audience']}
    Budget Range: {campaign_parameters['budget_range']}
    Campaign Objective: {campaign_parameters['campaign_objective']}

    Please provide a detailed campaign concept including:
    - Campaign Concept: (A catchy name and brief description of the overall idea)
    - Key Message: (The main thing we want to tell people)
    - Channels: (Where will we show this campaign? e.g., Social Media, TV, Email)
    - KPIs (Key Performance Indicators): (How will we measure if it's working? e.g., Website visits, Sales, Social Media Likes)

    Be creative and think outside the box! And please provide a reference or reason for why you think that way.
    """

    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(prompt_message)
    campaign_idea_text = response.text
    return campaign_idea_text

# Streamlit App starts here
st.title("Jenosize Marketing Campaign Ideation Tool")
st.header("Generate Creative Marketing Campaign Ideas with Gemini Pro")

st.markdown("Enter the campaign parameters below:")

industry = st.selectbox("Industry:", ["Fashion", "Technology", "Food", "Travel", "Education", "Other"])
target_audience = st.selectbox("Target Audience:", ["Teenagers", "Parents", "Businesses", "Students", "General Public", "Other"])
budget_range = st.selectbox("Budget Range:", ["Low", "Medium", "High"])
campaign_objective = st.selectbox("Campaign Objective:", ["Increase sales", "Build brand awareness", "Get website visits", "Lead generation", "Product launch", "Other"])

if st.button("Generate Idea"):
    campaign_parameters = {
        "industry": industry,
        "target_audience": target_audience,
        "budget_range": budget_range,
        "campaign_objective": campaign_objective,
    }
    with st.spinner("Talking to Gemini... Generating Idea..."):
        generated_idea = generate_campaign_idea_streamlit(campaign_parameters)

    if generated_idea:
        st.subheader("✨ Amazing Campaign Idea! ✨")
        st.write(generated_idea)
    else:
        st.error("Error generating idea. Please check your API key and try again.")
        st.info("Make sure you have set your Google API key in Streamlit secrets (instructions in README).")

st.sidebar.header("About")
st.sidebar.info(
    "This is a prototype Marketing Campaign Ideation Tool created using Google Gemini Pro and Streamlit.\n\n"
    "Enter campaign parameters in the main panel and click 'Generate Idea' to get creative marketing campaign suggestions.\n\n"
    "For setup instructions and more details, refer to the README.md file included in the zipped folder."
)