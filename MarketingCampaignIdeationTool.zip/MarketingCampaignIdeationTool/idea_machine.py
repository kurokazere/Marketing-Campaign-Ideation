#pip install google-generativeai

import google.generativeai as genai
import os

def get_campaign_info():
    """Asks the user for campaign parameters (industry, audience, budget, objective)."""
    print("Let's create a Marketing Campaign Idea!")
    industry = input("What industry is this campaign for? (e.g., Technology, Fashion, Food): ")
    target_audience = input("Who is the target audience? (e.g., Teenagers, Parents, Businesses): ")
    budget_range = input("What's the budget range? (e.g., Low, Medium, High): ")
    campaign_objective = input("What's the main goal? (e.g., Increase sales, Build brand awareness, Get website visits): ")

    campaign_parameters = {
        "industry": industry,
        "target_audience": target_audience,
        "budget_range": budget_range,
        "campaign_objective": campaign_objective,
    }
    return campaign_parameters

def generate_campaign_idea(campaign_parameters):
    """Generates a marketing campaign idea using Google Gemini Pro model."""

    # **IMPORTANT: Set your Google Gemini API key here! **
    # **Option 1:  Keep your API key SECRET using environment variables (RECOMMENDED)**
    #    1. Set an environment variable named GOOGLE_API_KEY with your API key value.
    #    macOS and Linux (Bash, Zsh, etc.)
    #           Using export command (Temporary - Session Specific):
    #           Open your terminal (e.g., Terminal on macOS, Bash on Linux).  Type the following command and press Enter:
    #    >> export GOOGLE_API_KEY="YOUR_ACTUAL_API_KEY_HERE" <<
    #    2. The code below will automatically get it from there.
    genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

    # **Option 2: For easier testing (but less secure), you can put your API key DIRECTLY below:**
    # genai.configure(api_key="YOUR_GEMINI_API_KEY_HERE") # <-- REPLACE with your ACTUAL API key if you use this option!
    # **If you use Option 2, make sure to REMOVE your API key before sharing your code!**

    # Check if API key is set (using a simple check, improve for real apps)
    api_key_set = False
    if os.getenv("GOOGLE_API_KEY") is not None or "YOUR_GEMINI_API_KEY_HERE" != "YOUR_GEMINI_API_KEY_HERE": # Crude check for direct input
        api_key_set = True

    if not api_key_set:
        print("Error: Google API key is not set! Please follow instructions in README.md to set it up.")
        return None

    prompt_message = f"""
    You're a key expert on our creative marketing team.

    Generate a creative marketing campaign idea for the following:

    Industry: {campaign_parameters['industry']}
    Target Audience: {campaign_parameters['target_audience']}
    Budget Range: {campaign_parameters['budget_range']}
    Campaign Objective: {campaign_parameters['campaign_objective']}

    Please provide a detailed campaign concept including:
    - Campaign Concept: (A catchy name and brief description of the overall idea)
    - Key Message: (The main thing we want to tell people)
    - Channels: (Where will we show this campaign? e.g., Social Media, TV, Email)
    - KPIs (Key Performance Indicators): (How will we measure if it's working? e.g., Website visits, Sales, Social Media Likes)

    Be creative and think outside the box! And please provide a reference or reason for why you think that way.
    """

    print("\nTalking to the Gemini super-smart parrot...")
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(prompt_message)
    campaign_idea_text = response.text
    return campaign_idea_text

if __name__ == "__main__":
    user_info = get_campaign_info()
    if user_info:
        generated_idea = generate_campaign_idea(user_info)
        if generated_idea:
            print("\n✨✨✨ AMAZING Marketing Campaign Idea ✨✨✨\n")
            print(generated_idea)
        else:
            print("\nSorry, I couldn't generate a campaign idea. Please check your API key and try again.")
    else:
        print("\nNo campaign information provided. Please run the script again and answer the questions.")