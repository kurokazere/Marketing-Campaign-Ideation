# Marketing Campaign Ideation Tool for Jenosize

This tool helps generate creative marketing campaign ideas using Google's Gemini Pro language model.

## Setup Instructions

1.  **Install Python:**  If you don't have Python installed, download and install it from [https://www.python.org/](https://www.python.org/).  Make sure to choose a Python 3.x version.

2.  **Install Required Python Libraries:** Open your command line or terminal and run the following command:

    ```bash
    pip install google-generativeai
    ```

3.  **Get a Google AI API Key:**
    *   Go to [https://makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey) and sign in with your Google account.
    *   Create a new project if needed.
    *   Click "Create API key in new project" and copy your API key.

4.  **Set your Google API Key:** You have two options to securely provide your API key to the tool:

    *   **Option 1: (Recommended - Using Environment Variables - More Secure)**
        *   Set an environment variable named `GOOGLE_API_KEY` on your computer and set its value to your API key you copied in step 3.
        *   How to set environment variables depends on your operating system (Windows, Mac, Linux). Search online for "how to set environment variables on \[your operating system]".
        *   **If you choose this option, you don't need to change the `idea_machine.py` code.**

    *   **Option 2: (Easier for testing - Less Secure - For personal use ONLY)**
        *   Open the `idea_machine.py` file in a text editor.
        *   Find the line that is commented out:
            `# genai.configure(api_key="YOUR_GEMINI_API_KEY_HERE") # <-- REPLACE with your ACTUAL API key if you use this option!`
        *   **Uncomment** this line by removing the `#` at the beginning.
        *   **Replace** `"YOUR_GEMINI_API_KEY_HERE"` with your **actual Google API key** that you copied in step 3.
        *   **WARNING:**  If you use this option, your API key will be directly in the code. **Be very careful not to share your code with anyone with your API key in it!**  This option is only recommended for your personal testing and learning.  For sharing or real applications, **ALWAYS use environment variables (Option 1).**

5.  **Run the Idea Machine:** Open your command line or terminal, navigate to the folder where you saved `idea_machine.py` (using the `cd` command), and run the script using:

    ```bash
    python idea_machine.py
    ```

    The tool will then ask you questions about the marketing campaign. Answer them, and it will generate a campaign idea!

## Example Usage

After following the setup instructions, run `python idea_machine.py`.  You will be prompted to enter campaign details. For example:

<!-- end list -->

## Potential Improvements

*   **More detailed parameters:**  Add options to specify product type, seasonality, competitor information, etc.
*   **Refine prompts:**  Experiment with different prompts to guide Gemini to generate even more creative and relevant ideas.
*   **User Interface:**  Create a web or desktop application with a user-friendly interface instead of command-line input. (See Prototype App in Deliverable 3)
*   **Idea saving and management:** Allow users to save, review, and compare generated campaign ideas.
*   **Integration with other tools:** Connect to marketing platforms for campaign planning and execution.
*   **Model selection:** Allow users to choose between different language models (Gemini Pro, other models in the future).

---

**Created for Jenosize Marketing Campaign Ideation Task.**